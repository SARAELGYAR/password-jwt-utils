const crypto = require('crypto');

/**
 * Signs a JWT token with the given payload and secret
 * @param {object} payload - The JWT payload
 * @param {string} secret - The secret key for signing
 * @param {number} expiresInSeconds - The token expiration time in seconds (default: 3600)
 * @returns {string} - The signed JWT token
 */
function signJWT(payload, secret, expiresInSeconds = 3600) {
  if (typeof payload !== 'object' || payload === null) {
    throw new TypeError('Payload must be an object');
  }
  if (typeof secret !== 'string' || !secret) {
    throw new TypeError('Secret must be a non-empty string');
  }
  if (typeof expiresInSeconds !== 'number' || expiresInSeconds <= 0) {
    throw new TypeError('expiresInSeconds must be a positive number');
  }

  // Create the JWT header
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  // Add expiration to payload
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const payloadWithExp = {
    ...payload,
    exp: currentTimestamp + expiresInSeconds
  };

  // Base64Url encode the header and payload
  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(payloadWithExp));

  // Create the data to be signed
  const dataToSign = `${encodedHeader}.${encodedPayload}`;

  // Sign the data using HMAC-SHA256
  const signature = crypto
    .createHmac('sha256', secret)
    .update(dataToSign)
    .digest();

  // Return the complete JWT
  return `${dataToSign}.${base64UrlEncode(signature)}`;
}

/**
 * Verifies a JWT token and returns the decoded payload if valid
 * @param {string} token - The JWT token to verify
 * @param {string} secret - The secret key used for signing
 * @returns {object} - The decoded payload if the token is valid
 * @throws {Error} - If the token is invalid or expired
 */
function verifyJWT(token, secret) {
  if (typeof token !== 'string') {
    throw new TypeError('Token must be a string');
  }
  if (typeof secret !== 'string' || !secret) {
    throw new TypeError('Secret must be a non-empty string');
  }

  // Split the token into parts
  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Invalid token format');
  }

  const [encodedHeader, encodedPayload, encodedSignature] = parts;

  // Verify the signature
  const dataToVerify = `${encodedHeader}.${encodedPayload}`;
  const signature = base64UrlDecode(encodedSignature);
  
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(dataToVerify)
    .digest();

  // Compare signatures using constant-time comparison
  if (!crypto.timingSafeEqual(signature, expectedSignature)) {
    throw new Error('Invalid token signature');
  }

  // Decode and parse the payload
  const payload = JSON.parse(base64UrlDecode(encodedPayload).toString());

  // Check if the token is expired
  const currentTimestamp = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < currentTimestamp) {
    throw new Error('Token has expired');
  }

  return payload;
}

/**
 * Encodes a buffer or string to base64url (with padding removed)
 * @param {string|Buffer} data - The data to encode
 * @returns {string} - The base64url encoded string
 */
function base64UrlEncode(data) {
  let buffer;
  if (Buffer.isBuffer(data)) {
    buffer = data;
  } else if (typeof data === 'string') {
    buffer = Buffer.from(data);
  } else {
    throw new TypeError('Data must be a string or Buffer');
  }

  // Convert to base64 and make URL safe
  return buffer.toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, ''); // Remove padding
}

/**
 * Decodes a base64url string to a buffer
 * @param {string} str - The base64url encoded string
 * @returns {Buffer} - The decoded buffer
 */
function base64UrlDecode(str) {
  // Make the string base64 standard compliant
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  
  // Add padding if needed
  while (base64.length % 4) {
    base64 += '=';
  }
  
  return Buffer.from(base64, 'base64');
}

module.exports = {
  signJWT,
  verifyJWT
};