const crypto = require('crypto');

/**
 * Hashes a password using PBKDF2 with a random salt
 * @param {string} password - The password to hash
 * @returns {string} - The salt and hash concatenated with a colon
 */
function hashPassword(password) {
  if (typeof password !== 'string') {
    throw new TypeError('Password must be a string');
  }

  // Generate a random salt
  const salt = crypto.randomBytes(16);
  
  // Hash the password using PBKDF2
  const hash = crypto.pbkdf2Sync(
    password,
    salt,
    100000, // 100,000 iterations
    64,     // 64 bytes key length
    'sha512'
  );

  // Return the salt and hash concatenated with a colon
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

/**
 * Verifies a password against a stored hash
 * @param {string} password - The password to verify
 * @param {string} storedHash - The stored hash in the format salt:hash
 * @returns {boolean} - True if the password matches, false otherwise
 */
function verifyPassword(password, storedHash) {
  if (typeof password !== 'string' || typeof storedHash !== 'string') {
    throw new TypeError('Password and storedHash must be strings');
  }

  // Split the stored hash into salt and hash
  const [saltHex, hashHex] = storedHash.split(':');
  
  if (!saltHex || !hashHex) {
    throw new Error('Invalid stored hash format');
  }

  // Convert the salt and hash from hex to Buffer
  const salt = Buffer.from(saltHex, 'hex');
  const storedHashBuf = Buffer.from(hashHex, 'hex');

  // Hash the provided password using the same parameters
  const computedHash = crypto.pbkdf2Sync(
    password,
    salt,
    100000, // 100,000 iterations
    64,     // 64 bytes key length
    'sha512'
  );

  // Compare the computed hash with the stored hash
  // Use a constant-time comparison to prevent timing attacks
  return crypto.timingSafeEqual(storedHashBuf, computedHash);
}

module.exports = {
  hashPassword,
  verifyPassword
};