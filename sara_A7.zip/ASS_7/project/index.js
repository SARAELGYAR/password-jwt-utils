// Example usage of password and JWT utilities
const { hashPassword, verifyPassword } = require('./password-utils');
const { signJWT, verifyJWT } = require('./jwt-utils');

console.log(`Hello Node.js v${process.versions.node}!`);

// Example of password hashing and verification
try {
  console.log('Password Utilities Demo:');
  const password = 'MySecurePassword123!';
  console.log(`Original password: ${password}`);
  
  // Hash the password
  const hashedPassword = hashPassword(password);
  console.log(`Hashed password: ${hashedPassword}`);
  
  // Verify the password
  const isValid = verifyPassword(password, hashedPassword);
  console.log(`Password verification result: ${isValid}`);
  
  // Verify with incorrect password
  const isInvalidPassword = verifyPassword('WrongPassword', hashedPassword);
  console.log(`Invalid password verification result: ${isInvalidPassword}`);
} catch (error) {
  console.error('Password utility error:', error.message);
}

// Example of JWT signing and verification
try {
  console.log('\nJWT Utilities Demo:');
  const payload = { userId: '12345', role: 'admin' };
  const secret = 'mySecretKey';
  
  // Sign a JWT
  const token = signJWT(payload, secret, 60); // Expires in 60 seconds
  console.log(`Generated JWT: ${token}`);
  
  // Verify the JWT
  const decodedPayload = verifyJWT(token, secret);
  console.log('Decoded payload:', decodedPayload);
  
  // Demonstrate expiration (uncomment to test)
  /*
  setTimeout(() => {
    try {
      const expiredPayload = verifyJWT(token, secret);
      console.log('Should not reach here if token is expired');
    } catch (error) {
      console.log('Expected error for expired token:', error.message);
    }
  }, 61000); // Wait for 61 seconds to test expiration
  */
} catch (error) {
  console.error('JWT utility error:', error.message);
}